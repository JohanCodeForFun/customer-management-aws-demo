#!/bin/bash
# Quick debug script for EB instance

echo "=== Checking Java Application ==="
ps aux | grep java

echo "=== Checking Environment Variables ==="
sudo printenv | grep -E "(RDS|SPRING|CORS|PORT)" | sort

echo "=== Recent Application Logs ==="
sudo tail -30 /var/log/web.stdout.log

echo "=== Recent Error Logs ==="
sudo tail -30 /var/log/web.stderr.log

echo "=== Port Status ==="
sudo netstat -tlnp | grep -E "(5000|8080)"

echo "=== Test Database Connection ==="
timeout 5 bash -c "</dev/tcp/$RDS_HOSTNAME/$RDS_PORT" && echo "Database port is open" || echo "Cannot connect to database"